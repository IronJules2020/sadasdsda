// vts values

// base location of vts
var locationngxvtstatus = "ngxvtstatus";

// vtsUpdateInterval, 2500=2,5seconds
var vtsUpdateIntervalvv = 2500;

// Streams that are down color in red
var vtsupstreamdown = "background:red; color:white;";

// Waiting connections color in red when above trigger value
var vtsconnwaiting = "background:red; color:white;";
var vtsconnwaitingtrigger = 1000;
