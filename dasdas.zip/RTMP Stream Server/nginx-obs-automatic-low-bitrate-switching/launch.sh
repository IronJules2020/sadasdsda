#!/bin/bash

program_dir=$(dirname "$0")

cd "$program_dir"
./noalbs
